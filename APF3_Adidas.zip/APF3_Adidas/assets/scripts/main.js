// Espera a que todo el HTML esté cargado antes de ejecutar el script
document.addEventListener('DOMContentLoaded', function() {
  
  // 1. Seleccionar los dos elementos que controlaremos
  const menuHamburguesa = document.getElementById('menu-hamburguesa');
  const navMenu = document.getElementById('nav-menu-principal');

  // 2. Verificar que ambos elementos existan (buena práctica)
  if (menuHamburguesa && navMenu) {
    
    // 3. Añadir el "oyente" de evento (click)
    menuHamburguesa.addEventListener('click', function() {
      
      // 4. La acción:
      // "classList.toggle" añade la clase 'nav-menu-visible' si no la tiene,
      // y la quita si ya la tiene.
      navMenu.classList.toggle('nav-menu-visible');
    });
  }
});